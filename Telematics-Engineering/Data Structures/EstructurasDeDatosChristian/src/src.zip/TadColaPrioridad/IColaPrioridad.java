package TadColaPrioridad;



public interface IColaPrioridad<T>{

	
	public void enQueue(int prio,T Valor);
	
	
	
}
