package Mundo;

import java.util.ArrayList;

/**
 * Clase principal del organizador de tareas.
 * 
 * inv:
 * casificaciones!=null
 * 
 * La relacion a clasificaciones debe estar inicializada. 
 * No puede haber dos clasificaciones con el mismo nombre.
 *
 */
public class Recuerdame {
	
	//-----------------------------------------------------------------
	// Relaciones
	//-----------------------------------------------------------------
	
	private ArrayList <Clasificacion> clasificaciones;
	
	
	//-----------------------------------------------------------------
	// Constructor
	//-----------------------------------------------------------------
	 /**
     * Constructor de la clase recuerdame.
     * 
     * Inicializa la realcion clasificaciones con un arraylist de <clasificacion>
     * Crea una clasificacion por defecto: Recordatorios
     * 
     *<br/><b>pos: </b> La relacion clasificaciones!=null
     *<br/><b>pos: </b> Se ha creado un nuevo objeto clasificaciones 
     */
	public Recuerdame(){
		clasificaciones = new ArrayList <Clasificacion>();
		
		Clasificacion nueva = new Clasificacion("Recordatorios","Pon aqui tus tareas sin clasificar");
		clasificaciones.add(nueva);
	}
	
	//-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------
	
	/**
	* Metodo que crea una tarea a un clasificacion del organizador.
	*  
	*<br/><b>pos: </b> Se ha creado una nueva tarea en una clasificacion.
	*
	*@param: nombreTarea, String con nombre de la tarea nombreTarea!= null && !nombreTarea.equals("")
	*@param: descripcionTarea,  String del resumen de la tarea descripcionTarea!=null
	*@param: clasifica, String con el nombre de la clasificacion en donde se crear� la tarea, clasifica!= null
	*@param: fechaRecordatorio, String de la fecha para recordar la tarea (opcional)
	*
	*@throws Si la tarea ya existe
	*
	*/
	public void anadirTarea(String nombreTarea, String descripcionTarea, String fechaRecordatorio, String clasifica)throws Exception{
		
		if(buscarClasificacion(clasifica).buscarTarea(nombreTarea) == null){
			
			buscarClasificacion(clasifica).crearTarea(nombreTarea, descripcionTarea, fechaRecordatorio);
			
		}else{
			
			throw new Exception("Esta tarea ya fue creada");
			
		}
	}
	
	/**
	* Metodo que crear una nueva clasificacion para las tareas.
	* 
	*<br/><b>pos: </b> se ha creado una nueva clasificacion.
	*
	*@param: nombreClas, String con nombre de la clase nombreClas!= null && !nombreClas.equals("")
	*@param: descripcionClas, String con resumen de la clasificacion descripcionClas!=null
	*
	*@throws si la clasificacion ya existe
	*/
	public void crearClasificacion(String nombreClas, String descripcionClas)throws Exception{
		
		if(buscarClasificacion(nombreClas)==null){

			clasificaciones.add(new Clasificacion(nombreClas, descripcionClas));
			
		}else{
			
			throw new Exception("Esta clasificacion ya fue creada");
		}
		
	}
	
	/**
	* Metodo que busca una clasificacion en el arraylist de clasificaciones, segun un nombre pasado por parametro
	* 
	*@param: nombreClas, nombre de la clasificacion a buscar nombreClas!= null && !nombreClas.equals("")
	*
	*@return Clasificacion, la clasificacacion encontrada con el nombre pasado por parametro
	*
	*/
	public Clasificacion buscarClasificacion(String clas){
		
		Clasificacion buscada = null;
		boolean seEncontro = false;
		
			for (int i = 0; i < clasificaciones.size() && seEncontro == false; i++) {
			
				if(clasificaciones.get(i).darNombre().equals(clas)){
				buscada = clasificaciones.get(i);
				}
			}
			
		return buscada;
	}
	
	
	/**
	* Metodo que elimina la tarea con el nombre pasado por parametro de la clasificacion con el nombre 
	* pasado por parametro.
	*  
	*<br/><b>pos: </b> Se eliminado una tarea.
	*
	*@param: nombreClas, String con nombre de la clasificacion a buscar, nombreClas!= null && !nombreClas.equals("")
	*@param: nombreTarea, String con nombre de la tarea a eliminar, nombreTarea!= null && !nombreTarea.equals("")
	*
	*/
	public void eliminarTarea(String nombreClas, String nombreTarea){
		
		buscarClasificacion(nombreClas).eliminarTarea(nombreTarea);
		
	}
	
	
	/**
	* Metodo que da como realizada una tarea cuando el usuario ya cumplio su pendiente
	*  
	*<br/><b>pos: </b> El atributo realizada de la tarea seleccionada cambia a true
	*
	*@param: nombreClas, String con nombre de la clasificacion a buscar, nombreClas!= null && !nombreClas.equals("")
	*@param: nombreTarea, String con nombre de la tarea a realizar, nombreTarea!= null && !nombreTarea.equals("")
	*
	*/
	public void realizarTarea(String nombreClas, String nombreTarea){
		
		buscarClasificacion(nombreClas).buscarTarea(nombreTarea).realizar();
		
	}
	
	
	
}


