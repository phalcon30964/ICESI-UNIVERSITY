package mundo;

/**
 * Clase encargada de gestionar las excepciones generadas por los errores con las ciudades 
 *
 */
public class rutaException extends Exception{

	
	public rutaException(String causa){
		
		super(causa);
		
	}
	
}

