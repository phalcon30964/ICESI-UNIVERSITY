package mundo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class Dia {
	private String fecha;
	private String colorRecomendado;
	private Dia siguiente;
	private Mensaje mensaje;
  
  public void Dia( String fecha,  String colorR) {
	  Date fecha2 = new Date();
	  SimpleDateFormat formato = new SimpleDateFormat("dd.MM.yy 'at' HH:mm:ss");
	  String fechaHoy  = formato.format(fecha); 
	  colorRecomendado = colorR;
	
  }

  public void agregarMensaje( String fec,  String colorR) {
	  
  }

  public Mensaje localizarUltimoMensaje() {
  return null;
  }

  public void eliminarMensaje( int idM) {
  }

  public Mensaje localizarMensaje( int idM ) {
	  Mensaje quien = null;
	  Mensaje actual = mensaje
	  
	  while(actual!=null){
		  int id = actual.darId();
		  if(id==actual.darId){
			  quien = actual;
			  actual.darSiguiente();
		  }
	  }
  return quien;
  }

  public Dia darSiguiente() {
  return siguiente;
  }

  public void cambiarSiguiente(Dia nuevo) {
	  this.siguiente = nuevo;
  }

  public String darFecha() {
  return fecha;
  }

  public String darColorRecomendado() {
  return colorRecomendado;
  }

}
