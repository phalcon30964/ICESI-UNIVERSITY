package mundo;

import java.util.ArrayList;


public class EnergiaParaLaVida{
	
	private Dia dia;
	private Mensaje mensaje;


  public void EnergiaParaLaVida() {
  }

  public void agregarDia( String fecha, String f) {
  }

  public synchronized Dia localizarDiaPorFecha( String t) {
  return null;
  }

  public Dia localizarUltimoDia() {
  return null;
  }

  public void organizarDiasPorFecha() {
  }

  public void agregarMensajeADia( String q ,  String w,  String r) {
  }

  public void eliminarMensajeADia( String x,  int d) {
  }

  public Dia darDiaFechaMasCerca() {
  return null;
  }
  public ArrayList darListaDias(){
	  return null;
  }



}
