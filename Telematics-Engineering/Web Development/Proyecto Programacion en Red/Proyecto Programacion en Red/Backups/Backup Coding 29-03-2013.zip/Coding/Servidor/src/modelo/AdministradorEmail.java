package modelo;

public class AdministradorEmail {
	
	public static void enviarMensaje(String mail, String mensaje){
	}

}
